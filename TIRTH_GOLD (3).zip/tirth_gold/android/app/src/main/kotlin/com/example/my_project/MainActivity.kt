package com.mycompany.tirthgold

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
