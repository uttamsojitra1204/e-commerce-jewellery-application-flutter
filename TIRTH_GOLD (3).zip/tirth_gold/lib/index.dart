// Export pages
export '/pages/gold_dimond/gold_dimond_widget.dart' show GoldDimondWidget;
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/j_for_women/j_for_women_widget.dart' show JForWomenWidget;
export '/pages/j_for_men/j_for_men_widget.dart' show JForMenWidget;
export '/pages/singup/singup_widget.dart' show SingupWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/my_cart/my_cart_widget.dart' show MyCartWidget;
export '/pages/checkout/checkout_widget.dart' show CheckoutWidget;
export '/pages/order_history/order_history_widget.dart' show OrderHistoryWidget;
export '/pages/my_profile/my_profile_widget.dart' show MyProfileWidget;
export '/pages/place_order/place_order_widget.dart' show PlaceOrderWidget;
export '/pages/order_cancelled/order_cancelled_widget.dart'
    show OrderCancelledWidget;
export '/pages/main_page/main_page_widget.dart' show MainPageWidget;
export '/pages/gold_bracelet/gold_bracelet_widget.dart' show GoldBraceletWidget;
export '/pages/addaddress/addaddress_widget.dart' show AddaddressWidget;
