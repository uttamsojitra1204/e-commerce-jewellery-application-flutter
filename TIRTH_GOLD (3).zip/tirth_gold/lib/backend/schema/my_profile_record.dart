import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MyProfileRecord extends FirestoreRecord {
  MyProfileRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "emailid" field.
  String? _emailid;
  String get emailid => _emailid ?? '';
  bool hasEmailid() => _emailid != null;

  // "mobileno" field.
  String? _mobileno;
  String get mobileno => _mobileno ?? '';
  bool hasMobileno() => _mobileno != null;

  // "address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  // "pincode" field.
  double? _pincode;
  double get pincode => _pincode ?? 0.0;
  bool hasPincode() => _pincode != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  bool hasState() => _state != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _emailid = snapshotData['emailid'] as String?;
    _mobileno = snapshotData['mobileno'] as String?;
    _address = snapshotData['address'] as String?;
    _pincode = castToType<double>(snapshotData['pincode']);
    _city = snapshotData['city'] as String?;
    _state = snapshotData['state'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('my_profile');

  static Stream<MyProfileRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MyProfileRecord.fromSnapshot(s));

  static Future<MyProfileRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MyProfileRecord.fromSnapshot(s));

  static MyProfileRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MyProfileRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MyProfileRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MyProfileRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MyProfileRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MyProfileRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMyProfileRecordData({
  String? name,
  String? emailid,
  String? mobileno,
  String? address,
  double? pincode,
  String? city,
  String? state,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'emailid': emailid,
      'mobileno': mobileno,
      'address': address,
      'pincode': pincode,
      'city': city,
      'state': state,
    }.withoutNulls,
  );

  return firestoreData;
}

class MyProfileRecordDocumentEquality implements Equality<MyProfileRecord> {
  const MyProfileRecordDocumentEquality();

  @override
  bool equals(MyProfileRecord? e1, MyProfileRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.emailid == e2?.emailid &&
        e1?.mobileno == e2?.mobileno &&
        e1?.address == e2?.address &&
        e1?.pincode == e2?.pincode &&
        e1?.city == e2?.city &&
        e1?.state == e2?.state;
  }

  @override
  int hash(MyProfileRecord? e) => const ListEquality().hash([
        e?.name,
        e?.emailid,
        e?.mobileno,
        e?.address,
        e?.pincode,
        e?.city,
        e?.state
      ]);

  @override
  bool isValidKey(Object? o) => o is MyProfileRecord;
}
