import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class WomenProductsRecord extends FirestoreRecord {
  WomenProductsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Item_name" field.
  String? _itemName;
  String get itemName => _itemName ?? '';
  bool hasItemName() => _itemName != null;

  // "Item_image" field.
  String? _itemImage;
  String get itemImage => _itemImage ?? '';
  bool hasItemImage() => _itemImage != null;

  // "item_description" field.
  String? _itemDescription;
  String get itemDescription => _itemDescription ?? '';
  bool hasItemDescription() => _itemDescription != null;

  // "item_price" field.
  double? _itemPrice;
  double get itemPrice => _itemPrice ?? 0.0;
  bool hasItemPrice() => _itemPrice != null;

  // "itemsize" field.
  List<int>? _itemsize;
  List<int> get itemsize => _itemsize ?? const [];
  bool hasItemsize() => _itemsize != null;

  void _initializeFields() {
    _itemName = snapshotData['Item_name'] as String?;
    _itemImage = snapshotData['Item_image'] as String?;
    _itemDescription = snapshotData['item_description'] as String?;
    _itemPrice = castToType<double>(snapshotData['item_price']);
    _itemsize = getDataList(snapshotData['itemsize']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('women_products');

  static Stream<WomenProductsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => WomenProductsRecord.fromSnapshot(s));

  static Future<WomenProductsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => WomenProductsRecord.fromSnapshot(s));

  static WomenProductsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      WomenProductsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static WomenProductsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      WomenProductsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'WomenProductsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is WomenProductsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createWomenProductsRecordData({
  String? itemName,
  String? itemImage,
  String? itemDescription,
  double? itemPrice,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Item_name': itemName,
      'Item_image': itemImage,
      'item_description': itemDescription,
      'item_price': itemPrice,
    }.withoutNulls,
  );

  return firestoreData;
}

class WomenProductsRecordDocumentEquality
    implements Equality<WomenProductsRecord> {
  const WomenProductsRecordDocumentEquality();

  @override
  bool equals(WomenProductsRecord? e1, WomenProductsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.itemName == e2?.itemName &&
        e1?.itemImage == e2?.itemImage &&
        e1?.itemDescription == e2?.itemDescription &&
        e1?.itemPrice == e2?.itemPrice &&
        listEquality.equals(e1?.itemsize, e2?.itemsize);
  }

  @override
  int hash(WomenProductsRecord? e) => const ListEquality().hash([
        e?.itemName,
        e?.itemImage,
        e?.itemDescription,
        e?.itemPrice,
        e?.itemsize
      ]);

  @override
  bool isValidKey(Object? o) => o is WomenProductsRecord;
}
