import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProductsRecord extends FirestoreRecord {
  ProductsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "itemname" field.
  String? _itemname;
  String get itemname => _itemname ?? '';
  bool hasItemname() => _itemname != null;

  // "itemimage" field.
  String? _itemimage;
  String get itemimage => _itemimage ?? '';
  bool hasItemimage() => _itemimage != null;

  // "itemdescription" field.
  String? _itemdescription;
  String get itemdescription => _itemdescription ?? '';
  bool hasItemdescription() => _itemdescription != null;

  // "itemprice" field.
  double? _itemprice;
  double get itemprice => _itemprice ?? 0.0;
  bool hasItemprice() => _itemprice != null;

  // "itemsize" field.
  List<int>? _itemsize;
  List<int> get itemsize => _itemsize ?? const [];
  bool hasItemsize() => _itemsize != null;

  void _initializeFields() {
    _itemname = snapshotData['itemname'] as String?;
    _itemimage = snapshotData['itemimage'] as String?;
    _itemdescription = snapshotData['itemdescription'] as String?;
    _itemprice = castToType<double>(snapshotData['itemprice']);
    _itemsize = getDataList(snapshotData['itemsize']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('products');

  static Stream<ProductsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProductsRecord.fromSnapshot(s));

  static Future<ProductsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProductsRecord.fromSnapshot(s));

  static ProductsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ProductsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProductsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProductsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProductsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProductsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProductsRecordData({
  String? itemname,
  String? itemimage,
  String? itemdescription,
  double? itemprice,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'itemname': itemname,
      'itemimage': itemimage,
      'itemdescription': itemdescription,
      'itemprice': itemprice,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProductsRecordDocumentEquality implements Equality<ProductsRecord> {
  const ProductsRecordDocumentEquality();

  @override
  bool equals(ProductsRecord? e1, ProductsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.itemname == e2?.itemname &&
        e1?.itemimage == e2?.itemimage &&
        e1?.itemdescription == e2?.itemdescription &&
        e1?.itemprice == e2?.itemprice &&
        listEquality.equals(e1?.itemsize, e2?.itemsize);
  }

  @override
  int hash(ProductsRecord? e) => const ListEquality().hash([
        e?.itemname,
        e?.itemimage,
        e?.itemdescription,
        e?.itemprice,
        e?.itemsize
      ]);

  @override
  bool isValidKey(Object? o) => o is ProductsRecord;
}
