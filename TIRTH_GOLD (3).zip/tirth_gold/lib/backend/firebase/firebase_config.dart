import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAuKzKTM8V9YNVEQhvXR2WSOXNo3BfAKb4",
            authDomain: "tirthgold-27acb.firebaseapp.com",
            projectId: "tirthgold-27acb",
            storageBucket: "tirthgold-27acb.appspot.com",
            messagingSenderId: "342930364712",
            appId: "1:342930364712:web:702dc3836a96ff93f9181d"));
  } else {
    await Firebase.initializeApp();
  }
}
